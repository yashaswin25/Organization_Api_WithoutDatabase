﻿using organization_new.Models;

namespace organization_new.DTO
{
    public class MembersDTO
    {
        public Guid Id { get; set; }
        public string? Name { get; set; }
        public int salary { get; set; }
        public int Age { get; set; }
        public DateTime JoiningDate { get; set; }
        public Guid ReportsTo { get; set; }
        public int HoursWorked { get; set; }
        public int WorkLoad { get; set; }
        public Guid TeamId { get; set; }
        //public string? role { get; set; }
    }
}
