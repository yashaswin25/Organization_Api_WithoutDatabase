﻿namespace organization_new.DTO
{
    public class CalculateSalaryDTO
    {
        public Guid EmployeeId { get; set; }
        public decimal OriginalSalary { get; set; }
        public decimal DeductedAmount { get; set; }
        public decimal FinalSalary { get; set; }
    }
}
