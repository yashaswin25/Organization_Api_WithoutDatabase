﻿using organization_new.Models;

namespace organization_new.DTO
{
    public class OrganizationDTO
    {
        public Guid Id { get; set; }
        public string? Name { get; set; }
        public string? Address { get; set; }
        public List<Employees>? Employees { get; set; } = new();
        public List<Team>? Teams { get; set; } = new();
    }
}
