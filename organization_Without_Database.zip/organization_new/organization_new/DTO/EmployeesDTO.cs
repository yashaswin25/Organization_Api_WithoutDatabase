﻿namespace organization_new.DTO
{
    public class EmployeesDTO
    {
        public Guid Id { get; set; }
        public string? Name { get; set; }
        public int Salary { get; set; }
        public int Age { get; set; }
        public DateTime Joining_date { get; set; }
        public Guid OrgId { get; set; }
        public int NoOfLeaves { get; set; }
    }
}
