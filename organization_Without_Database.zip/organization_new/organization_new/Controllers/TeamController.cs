﻿using Mapster;
using Microsoft.AspNetCore.Mvc;
using organization_new.DTO;
using organization_new.Models;
using organization_new.Repositries;

namespace organization_new.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TeamController : ControllerBase
    {
        private readonly ITeamRepository _teamRepository;
        private readonly IOrganizationRepository _organizationRepository;
        public readonly IMemberRepository _memberRepository;
        public readonly IEmployeeRepository _employeeRepository;

        public TeamController(ITeamRepository teamRepository,IOrganizationRepository organizationRepository,IMemberRepository memberRepository, IEmployeeRepository employeeRepository)
        {
            _teamRepository = teamRepository;
            _organizationRepository = organizationRepository;
            _memberRepository = memberRepository;
            _employeeRepository = employeeRepository;
        }

        [HttpGet("getAll")]
        public List<Team> GetAllTeams()
        {
            try
            {
                var teams = _teamRepository.GetTeams();
                if (teams == null)
                {
                    throw new NullReferenceException("No teams found.");
                }
                return teams;
            }
            catch (Exception)
            {
                throw new Exception($"An error occurred while retrieving teams");
            }
        }


        [HttpGet("getById/{id}")]
        public Team GetTeamById(Guid id)
        {
            try
            {
                var team = _teamRepository.GetTeamById(id);
                if (team == null)
                {
                    throw new NullReferenceException("Team not found.");
                }
                return team;
            }
            catch (Exception)
            {
                throw new Exception($"An error occurred while retrieving the team");
            }
        }



        [HttpGet("getByManager/{managerId}")]
        public Team GetTeamByManager(Guid managerId)
        {
            try
            {
                var team = _teamRepository.GetTeamByManagerId(managerId);
                if (team == null)
                {
                    throw new NullReferenceException($"Team managed by ID {managerId} not found.");
                }
                return team;
            }
            catch (Exception )
            {
                throw new Exception($"An error occurred while retrieving the team managed by {managerId}");
            }
        }


        [HttpPost("create")]
        public Team AddTeam(TeamsDTO teamDto)
        {
            try
            {
                var team = teamDto.Adapt<Team>();
                var organization = _organizationRepository.GetOrganizationById(team.OrgId);
                if (organization == null)
                {
                    throw new NullReferenceException("Organization ID not found.");
                }
                organization.Teams?.Add(team);
                var manager = _employeeRepository.GetById(teamDto.ManagerId);
                if (manager == null)
                {
                    throw new NullReferenceException("Manager (employee) with ID not found.");
                }
                team.ManagerId = manager.Id;
                Team addedTeam = _teamRepository.Add(team);
                if (team.Members != null)
                {
                    foreach (var member in team.Members)
                    {
                        member.Id = team.Id; 
                        member.ReportsTo = team.ManagerId;
                        member.TeamId = team.Id;
                        _memberRepository.AddMember(member);
                    }
                }
                return addedTeam;
            }
            catch (Exception )
            {
                throw new Exception($"An error occurred while adding the team");
            }
        }


        [HttpGet("getTotalEfforts/{id}")]
        public string GetTotalEfforts(Guid id)
        {
            try
            {
                var team = _teamRepository.GetTeamById(id);
                if (team == null)
                {
                    throw new NullReferenceException($"Team ID not found.");
                }
                List<Member>? members = team.Members;
                decimal totalHoursWorked = 0;
                foreach (var member in members)
                {
                    totalHoursWorked += member.HoursWorked;
                }
                return $"Total hours worked by {team.Name} team: {totalHoursWorked}";
            }
            catch (Exception )
            {
                throw new Exception($"An error occurred while calculating total efforts");
            }
        }


    }
}
