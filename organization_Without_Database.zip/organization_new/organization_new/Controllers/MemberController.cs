﻿using Mapster;
using Microsoft.AspNetCore.Mvc;
using organization_new.DTO;
using organization_new.Models;
using organization_new.Repositries;

namespace organization_new.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MemberController : ControllerBase
    {
        private readonly IMemberRepository _memberRepository;
        private readonly ITeamRepository _teamRepository;

        public MemberController(IMemberRepository memberRepository, ITeamRepository teamRepository)
        {
            _memberRepository = memberRepository;
            _teamRepository = teamRepository;
        }

        [HttpGet("getAll")]
        public List<Member> GetAllMembers()
        {
            try
            {
                var members = _memberRepository.GetAll();
                if (members == null) 
                {
                    throw new NullReferenceException("No members found.");
                }
                return members;
            }
            catch (Exception)
            {
                throw new Exception($"An error occurred while retrieving members");
            }
        }

        [HttpGet("getBy/{id}")]
        public Member GetMemberById(Guid id)
        {
            try
            {
                var member = _memberRepository.GetMemberById(id);
                if (member == null)
                {
                    throw new NullReferenceException("Member not found.");
                }
                return member;
            }
            catch (Exception )
            {
                throw new Exception($"An error occurred while retrieving the member");
            }
        }


        [HttpPost("Create")]
        public Member AddMember(MembersDTO memberDTO)
        {
            try
            {
                Team? team = _teamRepository.GetTeamById(memberDTO.TeamId);
                if (team == null)
                {
                    throw new Exception("Team not found.");
                }
                Member member = memberDTO.Adapt<Member>();
                team.Members.Add(member);
                member.ReportsTo = team.ManagerId;
                member.TeamId = team.Id;

                Member _member = _memberRepository.AddMember(member);
                return _member;
            }
            catch (Exception)
            {
                throw new Exception($"An error occurred while adding the member");
            }
        }



        [HttpPut("update/{id}")]
        public Member UpdateMember(Guid id, Member member)
        {
            try
            {
                var updatedMember = _memberRepository.UpdateMember(id, member);
                if (updatedMember == null)
                {
                    throw new Exception("Member not found.");
                }
                return updatedMember;
            }
            catch (Exception)
            {
                throw new Exception($"An error occurred while updating the member");
            }
        }


        [HttpDelete("delete/{id}")]
        public void DeleteMember(Guid id)
        {
            try
            {
                var member = _memberRepository.GetMemberById(id);
                if (member == null)
                {
                    throw new NullReferenceException("Member not found.");
                }

                _memberRepository.DeleteMember(id);
            }
            catch (Exception)
            {
                throw new Exception($"An error occurred while deleting the member");
            }
        }


        [HttpPut("ReassignMember/{memberId}/to/{newTeamId}")]
        public Member ReassignMember(Guid memberId, Guid newTeamId)
        {
            try
            {
                Member member = _memberRepository.GetMemberById(memberId);
                if (member == null)
                {
                    throw new NullReferenceException("Member not found.");
                }
                Team currentTeam = _teamRepository.GetTeamById(member.TeamId);
                if (currentTeam == null)
                {
                    throw new NullReferenceException("Current team not found.");
                }
                Team newTeam = _teamRepository.GetTeamById(newTeamId);
                if (newTeam == null)
                {
                    throw new NullReferenceException("New team not found.");
                }
                currentTeam.Members?.Remove(member);
                member.TeamId = newTeamId;
                member.ReportsTo = newTeam.ManagerId;
                newTeam.Members?.Add(member);
                return member;
            }
            catch (Exception )
            {
                throw new Exception($"An error occurred while reassigning the member");
            }
        }

        [HttpPut("changeRole/{memberId}")]
        public Member changeRole(Guid memberId, string newRole)
        {
            try
            {
                Member member = _memberRepository.GetMemberById(memberId);
                if (member == null)
                {
                    throw new NullReferenceException("Member not found.");
                }
                member.Role = newRole;
                _memberRepository.UpdateMember(memberId, member);
                return member;
            }
            catch (Exception)
            {
                throw new Exception($"An error occurred while changing the member's role");
            }
        }

    }
}
