﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using organization_new.DTO;
using organization_new.Models;
using organization_new.Repositries;
using Mapster;

namespace organization_new.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeesController : ControllerBase
    {
        private readonly IEmployeeRepository _employeeRepository;
        private readonly IOrganizationRepository _organizationRepository;
        private readonly IEmployeesalary _employeesalaryRepository;
        public EmployeesController(IEmployeeRepository employeeRepository, IOrganizationRepository organizationRepository, IEmployeesalary employeesalaryRepository)
        {
            _employeeRepository = employeeRepository;
            _organizationRepository = organizationRepository;
            _employeesalaryRepository = employeesalaryRepository;
        }
        [HttpGet]
        public List<Employees> GetAllEmployees()
        {
            try
            {
                var employees = _employeeRepository.GetAll();
                if (employees == null)
                {
                    throw new Exception("No employees found.");
                }
                return employees;
            }
            catch (Exception)
            {
                throw new Exception("An error occurred while retrieving employees");
            }
        }


        [HttpPost("AddEmployee")]
        public Employees AddEmployee(EmployeesDTO employeesDTO)
        {
            try
            {
                Organization organization = _organizationRepository.GetOrganizationById(employeesDTO.OrgId);
                if (organization == null)
                {
                    throw new Exception("Organization not found.");
                }
                Employees employee = employeesDTO.Adapt<Employees>();
                if (organization.Employees == null)
                {
                    organization.Employees = new List<Employees>();
                }
                organization.Employees.Add(employee);
                Employees addedEmployee = _employeeRepository.Add(employee);

                return addedEmployee;
            }
            catch (Exception)
            {
                throw new Exception("An error occurred while adding the employee");
            }
        }


        [HttpGet("employee/{id}")]
        public Employees GetEmployeeById(Guid id)
        {
            try
            {
                var employee = _employeeRepository.GetById(id);
                if (employee == null)
                {
                    throw new Exception("Employee not found.");
                }
                return employee;
            }
            catch (Exception)
            {
                throw new Exception($"An error occurred while retrieving the employee");
            }
        }

        [HttpPut("{id}")]
        public Employees UpdateEmployee(Guid id, EmployeesDTO employeeDTO)
        {
            try
            {
                var existingEmployee = _employeeRepository.GetById(id);
                if (existingEmployee == null)
                {
                    throw new NullReferenceException("Employee not found.");
                }
                _employeeRepository.Update(id, employeeDTO);
                return _employeeRepository.GetById(id);
            }
            catch (Exception)
            {
                throw new Exception($"An error occurred while updating the employee");
            }
        }


        [HttpDelete("DeleteEmployee/{id}")]
        public Employees DeleteEmployee(Guid id)
        {
            try
            {
                var employee = _employeeRepository.GetById(id);
                if (employee == null)
                {
                    throw new NullReferenceException("Employee not found.");
                }
                _employeeRepository.Delete(id);
                return employee;
            }
            catch (Exception )
            {
                throw new Exception($"Something went wrong while deleting the employee");
            }
        }


        [HttpGet("CalculateSalary/{employeeId}")]
        public CalculateSalaryDTO CalculateSalary(Guid employeeId)
        {
            try
            {
                Employees emp = _employeeRepository.GetById(employeeId);
                if (emp == null)
                {
                    throw new NullReferenceException("Employee not found.");
                }
                var response = _employeesalaryRepository.CalculateSalary(employeeId, emp.NoOfLeaves);
                if (response == null)
                {
                    throw new NullReferenceException("Salary calculation failed.");
                }
                return response;
            }
            catch (Exception)
            {
                throw new Exception($"An error occurred while calculating the salary");
            }
        }

    }
}


