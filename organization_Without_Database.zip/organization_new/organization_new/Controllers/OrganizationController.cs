﻿using Mapster;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using organization_new.DTO;
using organization_new.Models;
using organization_new.Repositries;
using System.Diagnostics;

namespace organization_new.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrganizationController
    {
        private readonly IOrganizationRepository _organizationRepository;
        private readonly IEmployeeRepository _employeeRepository;
        private readonly ITeamRepository _teamRepository;
        private readonly IMemberRepository _memberRepository;


        public OrganizationController(IOrganizationRepository organizationRepository,IEmployeeRepository employeeRepository,ITeamRepository teamRepository,IMemberRepository memberRepository)
        {
            _organizationRepository = organizationRepository;
            _employeeRepository = employeeRepository;
            _teamRepository = teamRepository;
            _memberRepository = memberRepository;
        }

        [HttpGet("getAll")]
        public List<Organization> GetAllOrganization()
        {
            try
            {
                List<Organization> orgs = _organizationRepository.GetAllOrganization();
                if (orgs == null)
                {
                    throw new NullReferenceException("No Organization Found");
                }
                return orgs;
            }
            catch (Exception)
            {
                throw new Exception("An error occurred while fetching organizations");
            }
        }

        [HttpGet("getBy/{id}")]
        public Organization GetOrganization(Guid id)
        {
            try
            {
                var organization = _organizationRepository.GetOrganizationById(id);
                if (organization == null)
                {
                    throw new NullReferenceException("No Organization Found");
                }
                return organization;
            }
            catch (Exception)
            {
                throw new Exception("Error while retrieving organization");
            }
        }

        [HttpPost("add")]
        public Organization AddOrganization(OrganizationDTO organizationDTO)
        {
            try
            {
                var organization = organizationDTO.Adapt<Organization>();
                Organization org = _organizationRepository.AddOrganization(organization);
                List<Employees>? listEmp = org.Employees;
                if (listEmp != null)
                {
                    foreach (Employees? emp in listEmp)
                    {
                        if (emp != null)
                        {
                            emp.OrgId = organization.Id;
                            _employeeRepository.Add(emp);
                        }
                    }
                }
                List<Team>? teams = org.Teams;
                if (teams != null)
                {
                    foreach (Team? team in teams)
                    {
                        if (team != null)
                        {
                            team.OrgId = organization.Id;
                            var manager = _employeeRepository.GetById(team.ManagerId);
                            if (manager == null)
                            {
                                throw new NullReferenceException("Manager not found for Team ");
                            }
                            team.ManagerId = manager.Id;
                            List<Member>? members = team.Members;
                            if (members != null)
                            {
                                foreach (Member member in members)
                                {
                                    member.TeamId = team.Id;
                                    member.ReportsTo = team.ManagerId;
                                    _memberRepository.AddMember(member);
                                }
                            }
                            _teamRepository.Add(team);
                        }
                    }
                }
                return org; 
            }
            catch (Exception)
            {
                throw new Exception("An error occurred while adding the organization ");
            }
        }

    }
}
