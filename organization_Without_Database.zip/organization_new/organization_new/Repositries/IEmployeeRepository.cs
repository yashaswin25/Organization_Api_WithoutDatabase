﻿using organization_new.DTO;
using organization_new.Models;

namespace organization_new.Repositries
{
    public interface IEmployeeRepository
    {
        List<Employees> GetAll();
        Employees GetById(Guid id);
        Employees Add(Employees employee);
        void Update(Guid id,EmployeesDTO employeeDTO);
        void Delete(Guid id);
    }
}
