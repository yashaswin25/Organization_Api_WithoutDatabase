﻿using organization_new.Models;

namespace organization_new.Repositries
{
    public class OrganizationRepository : IOrganizationRepository
    {
        List<Organization> _Orgnization = new List<Organization>();

        public Organization AddOrganization(Organization organization)
        {
            organization.Id= Guid.NewGuid();
            _Orgnization.Add(organization);
            return organization;
        }

        public List<Organization> GetAllOrganization()
        {
            return _Orgnization;
        }

        public Organization GetOrganizationById(Guid id)
        {
            return _Orgnization?.FirstOrDefault(o => o.Id == id);
        }
    }
}
