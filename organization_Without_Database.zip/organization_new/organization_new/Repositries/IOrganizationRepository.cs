﻿using organization_new.Models;

namespace organization_new.Repositries
{
    public interface IOrganizationRepository
    {
        Organization AddOrganization(Organization organization);
        Organization GetOrganizationById(Guid id);
        List<Organization> GetAllOrganization();
    }
}
