﻿using organization_new.Models;

namespace organization_new.Repositries
{
    public class TeamRepository : ITeamRepository
    {
        List<Team> _Teams = new List<Team>();
        public Team Add(Team team)
        {
            team.Id = Guid.NewGuid();
            _Teams.Add(team);
            return team;
        }

        public Team GetTeamById(Guid id)
        {
            var user = _Teams.FirstOrDefault(x=>x.Id == id);
            if (user == null)
            {
                throw new NullReferenceException("not found");
            }
            return user;
        }

        public Team GetTeamByManagerId(Guid managerId)
        {
            var user = _Teams.FirstOrDefault(x=>x.ManagerId == managerId);
            if (user == null)
            {
                throw new NullReferenceException("team not found");
            }
            return user;
        }

        public List<Team> GetTeams()
        {
            return _Teams;
        }
    }
}
