﻿using organization_new.Models;
using organization_new.DTO;
using Mapster;
namespace organization_new.Repositries
{
    public class EmployeeRepositrory : IEmployeeRepository
    {
        List<Employees> Employees = new List<Employees>();
        public Employees Add(Employees employee)
        {
            employee.Id = Guid.NewGuid();
            Employees.Add(employee);
            return employee;
        }

        public void Delete(Guid id)
        {
            Employees.RemoveAll(s=>s.Id== id);
        }

        public List<Employees> GetAll()
        {
            return Employees;
        }

        public Employees GetById(Guid id)
        {
            var user = Employees.FirstOrDefault(s => s.Id == id);
            if (user == null)
            {
                throw new NullReferenceException("Employee not found");
            }
            return user;
        }

        public void Update(Guid id,EmployeesDTO employeeDTO)
        {   
            var user = Employees.FirstOrDefault(s=>s.Id== id);
            if(user!=null)
            {
                employeeDTO.Adapt(user);
            }
            else
            {
                throw new Exception("employe not found");
            }
        }
    }
}
