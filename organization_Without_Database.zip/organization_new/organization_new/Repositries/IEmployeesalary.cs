﻿using organization_new.DTO;

namespace organization_new.Repositries
{
    public interface IEmployeesalary
    {
        CalculateSalaryDTO CalculateSalary(Guid employeeId, int numberOfLeaves);
    }
}
