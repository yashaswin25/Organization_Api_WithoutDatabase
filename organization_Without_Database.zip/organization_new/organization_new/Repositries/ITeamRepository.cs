﻿using organization_new.Models;

namespace organization_new.Repositries
{
    public interface ITeamRepository
    {
        List<Team> GetTeams();
        Team GetTeamById(Guid id);
        Team Add(Team team);
        Team GetTeamByManagerId(Guid managerId);

    }
}
