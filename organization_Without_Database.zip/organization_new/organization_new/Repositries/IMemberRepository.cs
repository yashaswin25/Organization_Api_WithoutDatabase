﻿using organization_new.Models;

namespace organization_new.Repositries
{ 
    public interface IMemberRepository
    {
        List<Member> GetAll();
        Member GetMemberById(Guid id);
        public void DeleteMember(Guid id);
        Member AddMember(Member member);
        Member UpdateMember(Guid id,Member member);
    }
}
