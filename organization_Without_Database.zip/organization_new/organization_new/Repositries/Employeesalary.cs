﻿using organization_new.DTO;
using organization_new.Models;

namespace organization_new.Repositries
{
    public class Employeesalary : IEmployeesalary
    {
        public readonly IEmployeeRepository _employeeRepository;
        public Employeesalary(IEmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }
        public CalculateSalaryDTO CalculateSalary(Guid employeeId, int numberOfLeaves)
        {
            Employees employee = _employeeRepository.GetById(employeeId);
            if (employee == null)
            {
                throw new Exception("Employee not found");
            }
            decimal dailyPay = employee.Salary / 30;
            decimal deducted = dailyPay * employee.NoOfLeaves;
            decimal finalsalary = employee.Salary - deducted;

            return new CalculateSalaryDTO
            {
                EmployeeId = employee.Id,
                OriginalSalary = employee.Salary,
                DeductedAmount = deducted,
                FinalSalary = finalsalary
            };
        }
    }
}
