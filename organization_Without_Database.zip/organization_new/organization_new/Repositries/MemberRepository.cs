﻿using organization_new.Models;

namespace organization_new.Repositries
{
    
    public class MemberRepository : IMemberRepository
    {
        List<Member> _members = new List<Member>();
        public Member AddMember(Member member)
        {
            member.Id=Guid.NewGuid();
            _members.Add(member);
            return member;
        }

        public void DeleteMember(Guid id)
        {
            var user = _members.FirstOrDefault(x=>x.Id==id);
            if(user != null)
            {
                _members.Remove(user);
            }
            else
            {
                throw new Exception("user not found");
            }
        }

        public List<Member> GetAll()
        {
            return _members;
        }

        public Member GetMemberById(Guid id)
        {
            var member = _members.FirstOrDefault(x => x.Id == id);
            if (member == null)
            {
                throw new Exception("member not found");
            }
            return member;
        }

        public Member UpdateMember(Guid id, Member member)
        {
            var user = _members.FirstOrDefault(x=>x.Id==id);
            if(user == null)
            {
                throw new Exception("member not found");
            }
            user.Name = member.Name;
            user.Age = member.Age;
            user.HoursWorked = member.HoursWorked;
            user.WorkLoad = member.WorkLoad;
            user.JoiningDate = member.JoiningDate;
            return user;
        }
    }
}
