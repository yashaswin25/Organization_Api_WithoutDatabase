﻿using Mapster;
using organization_new.DTO;
using organization_new.Models;

namespace organization_new.Configuration
{
    public class MapsterConfig
    {
        public static void Mapping()
        {
            TypeAdapterConfig<OrganizationDTO, Organization>.NewConfig()
                .Map(dest => dest.Id, src => src.Id)
                .Map(dest => dest.Name, src => src.Name)
                .Map(dest => dest.Address, src => src.Address)
                .Map(dest => dest.Teams, src => src.Teams)
                .Map(dest => dest.Employees, src => src.Employees);

            TypeAdapterConfig<Organization, OrganizationDTO>.NewConfig()
                .Map(dest => dest.Id, src => src.Id)
                .Map(dest => dest.Name, src => src.Name)
                .Map(dest => dest.Address, src => src.Address)
                .Map(dest => dest.Teams, src => src.Teams)
                .Map(dest => dest.Employees, src => src.Employees);

            TypeAdapterConfig<EmployeesDTO, Employees>.NewConfig()
                .Map(dest => dest.Name, src => src.Name)
                .Map(dest => dest.Age, src => src.Age)
                .Map(dest => dest.Joining_date, src => src.Joining_date)
                .Map(dest => dest.Salary, src => src.Salary);

            TypeAdapterConfig<Employees, EmployeesDTO>.NewConfig()
                .Map(dest => dest.Name, src => src.Name)
                .Map(dest => dest.Age, src => src.Age)
                .Map(dest => dest.Joining_date, src => src.Joining_date)
                .Map(dest => dest.Salary, src => src.Salary);


            TypeAdapterConfig<TeamsDTO, Team>.NewConfig()
              .Map(dest => dest.Id, src => src.Id)
              .Map(dest => dest.Name, src => src.Name)
              .Map(dest => dest.ManagerId, src => src.ManagerId)
              .Map(dest => dest.Members, src => src.Members.Adapt<List<Member>>());

            TypeAdapterConfig<Team, TeamsDTO>.NewConfig()
              .Map(dest => dest.Id, src => src.Id)
              .Map(dest => dest.Name, src => src.Name)
              .Map(dest => dest.ManagerId, src => src.ManagerId)
              .Map(dest => dest.Members, src => src.Members.Adapt<List<Member>>());

            TypeAdapterConfig<MembersDTO,Member>.NewConfig()
                .Map(dest => dest.Id, src => src.Id)
                .Map(dest => dest.Name, src => src.Name)
                .Map(dest => dest.TeamId, src => src.TeamId)
                .Map(dest => dest.Age, src => src.Age)
                .Map(dest => dest.Salary, src => src.salary)
                .Map(dest => dest.JoiningDate, src => src.JoiningDate)
                .Map(dest => dest.ReportsTo, src => src.ReportsTo)
                .Map(dest => dest.HoursWorked, src => src.HoursWorked)
                .Map(dest => dest.WorkLoad, src => src.WorkLoad);

            TypeAdapterConfig<Member, MembersDTO>.NewConfig()
                .Map(dest => dest.Id, src => src.Id)
                .Map(dest => dest.Name, src => src.Name)
                .Map(dest => dest.TeamId, src => src.TeamId)
                .Map(dest => dest.Age, src => src.Age)
                .Map(dest => dest.salary, src => src.Salary)
                .Map(dest => dest.JoiningDate, src => src.JoiningDate)
                .Map(dest => dest.ReportsTo, src => src.ReportsTo)
                .Map(dest => dest.HoursWorked, src => src.HoursWorked)
                .Map(dest => dest.WorkLoad, src => src.WorkLoad);

        }
    }
}
