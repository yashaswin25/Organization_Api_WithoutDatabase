﻿    namespace organization_new.Models
    {
        public class Organization
        {
            public Guid Id { get; set; }
            public string ? Name {  get; set; }
            public string ? Address {  get; set; }
            public List<Employees>? Employees { get; set; } = new List<Employees>();
            public List<Team> ? Teams { get; set; }
        }
    }