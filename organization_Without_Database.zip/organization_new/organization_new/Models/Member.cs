﻿namespace organization_new.Models
{
    public class Member
    {
        public Guid Id { get; set; }    
        public string ? Name { get; set; }
        public int Salary {  get; set; }
        public int Age {  get; set; }
        public DateTime JoiningDate { get; set; }
        public Guid ReportsTo {get; set; }
        public int HoursWorked { get; set; }
        public int WorkLoad {  get; set; }
        public Guid TeamId { get; set; }
        public string ?Role { get; set; }
    }
}
