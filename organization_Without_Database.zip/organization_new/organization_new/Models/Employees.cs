﻿namespace organization_new.Models
{
    public class Employees
    {
       
        public Guid Id { get; set; }
        public string ? Name { get; set; }
        public int Salary { get; set; }
        public int Age { get; set; }
        public DateTime Joining_date { get; set; }
        public Guid OrgId { get; set; }
        public int NoOfLeaves {  get; set; }

        
    }
}
